// Anniversary counter
const startDate = new Date('2024-04-14');
function updateCounter() {
  const now = new Date();
  const diff = now - startDate;
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  document.getElementById('counter').textContent = `Kita sudah bersama selama ${days} hari ❤️`;
}
updateCounter();

// Quotes romantis
const quotes = [
  "Cintamu adalah alasan aku tersenyum setiap hari.",
  "Bersamamu, dunia terasa lebih indah.",
  "Aku ingin menua bersamamu, menulis cerita tanpa akhir.",
  "Kamu adalah rumah, tempat hati ini selalu kembali.",
  "Setiap detik bersamamu adalah anugerah terindah."
];
document.getElementById('quoteText').textContent =
  quotes[Math.floor(Math.random() * quotes.length)];

// Diary
function loadDiary() {
  const diary = JSON.parse(localStorage.getItem('diary')) || [];
  const list = document.getElementById('diaryList');
  list.innerHTML = '';
  diary.forEach((entry, idx) => {
    const li = document.createElement('li');
    li.textContent = entry;
    list.appendChild(li);
  });
}
function saveDiary() {
  const input = document.getElementById('diaryInput').value.trim();
  if (!input) return;
  const diary = JSON.parse(localStorage.getItem('diary')) || [];
  diary.push(input);
  localStorage.setItem('diary', JSON.stringify(diary));
  document.getElementById('diaryInput').value = '';
  loadDiary();
}
loadDiary();

// Galeri Foto & Video
function loadGallery() {
  const gallery = JSON.parse(localStorage.getItem('gallery')) || [];
  const container = document.getElementById('galleryContainer');
  container.innerHTML = '';
  gallery.forEach(item => {
    if(item.type.startsWith('image/')) {
      const img = document.createElement('img');
      img.src = item.src;
      container.appendChild(img);
    } else if(item.type.startsWith('video/')) {
      const video = document.createElement('video');
      video.src = item.src;
      video.controls = true;
      container.appendChild(video);
    }
  });
}
document.getElementById('uploadMedia').addEventListener('change', e => {
  const files = Array.from(e.target.files);
  const gallery = JSON.parse(localStorage.getItem('gallery')) || [];
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = () => {
      gallery.push({src: reader.result, type: file.type});
      localStorage.setItem('gallery', JSON.stringify(gallery));
      loadGallery();
    };
    reader.readAsDataURL(file);
  });
});
loadGallery();
